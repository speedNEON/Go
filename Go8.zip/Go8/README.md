# UPDATE 12-12-2018<br>
# SC INI FREE TIDAK UNTUK DINPERJUALBELIKAN<br>
# HARAP GUNAKAN DENGAN BIJAK<br>
# SUPORT BY SILENT TEAM BOT<br>
# BEBEK BOT TEAM & JUNSAN JUNIORS<br>
# SELFBOT + 7asist <br>
# SEKEDAR BERBAGI ILMU BIAR BISA BERKEMBANG KETIKA LO SUDH DI ATAS JANGAN PERNAH SOMBONG DENGAN KARYA LO KARNA DULU LO BUKAN SIAPA-SIAPA.. <br>


# Cara install <br>

apt-get update -y <br>
pkg install python -y <br>
pkg install python2 -y <br>
apt-get install git -y <br>
apt-get install python3-pip -y <br> 
pip3 install rsa <br> 
pip3 install thrift==0.11.0 <br> 
pip3 install requests <br> 
pip3 install pytz <br> 
pip3 install bs4 <br> 
sudo pip3 install gtts <br> 
pip3 install googletrans <br> 
pip3 install humanfriendly<br> 
pip3 install goslate<br> 
pip3 install pafy<br> 
pip3 install wikipedia <br> 
pip3 install tweepy<br> 
pip3 install youtube_dl<br> 
git clone https://github.com/dhenza1415/DHENZA<br> 
ls<br> 
cd DHENZA<br> 
ls<br> 
python3 dhenzapro.py<br> 






Note : @ Jika ingin instal pke vps tinggal tambah sudo di depan command<br> 
       @ Klo mau pake antijs+ghost tgal hapus bckup sw+dz di op.type 13&19<br>

source : linepy by https://github.com/dhenza1415<br>
## Like dan subscribe chanel youtube :( https://youtu.be/CRqXKcTl6IY)<br>
## [SUBCRABE NOW](https://www.youtube.com/channel/UCNLejYy84XyUX8qcDropXMw)
KLIK
## [CREATOR](http://line.me/ti/p/~teambotprotect)
